using System;
using System.Data;
using Microsoft.Data.SqlClient;

namespace DemoExam_V3_11
{
    public static class DatabaseInitializer
    {
        public const string DatabaseName = "DemoExam_V3_11";
        private static readonly string[] ServerCandidates = { @".\SQLEXPRESS", @"(localdb)\MSSQLLocalDB", "localhost" };
        public static string ServerName { get; private set; } = @".\SQLEXPRESS";
        public static string AppConnectionString => $"Data Source={ServerName};Initial Catalog={DatabaseName};Integrated Security=True;TrustServerCertificate=True;Encrypt=False";
        private static string MasterConnectionString => $"Data Source={ServerName};Initial Catalog=master;Integrated Security=True;TrustServerCertificate=True;Encrypt=False";

        public static void EnsureDatabase()
        {
            Exception lastError = null;
            foreach (var server in ServerCandidates)
            {
                try
                {
                    ServerName = server;
                    using (var connection = new SqlConnection(MasterConnectionString))
                    using (var command = connection.CreateCommand())
                    {
                        connection.Open();
                        command.CommandText = $"IF DB_ID(N'{DatabaseName.Replace("'", "''")}') IS NULL CREATE DATABASE [{DatabaseName}]";
                        command.ExecuteNonQuery();
                    }
                    CreateSchema();
                    SeedData();
                    SeedAuthUsers();
                    return;
                }
                catch (Exception ex)
                {
                    lastError = ex;
                }
            }
            throw new InvalidOperationException("Не удалось подключиться ни к одному SQL Server из списка.", lastError);
        }

        private static void ExecuteBatch(params string[] commands)
        {
            using var connection = new SqlConnection(AppConnectionString);
            connection.Open();
            foreach (var sql in commands)
            {
                using var command = new SqlCommand(sql, connection);
                command.ExecuteNonQuery();
            }
        }

        private static void CreateSchema()
        {
            ExecuteBatch(
@"IF OBJECT_ID('dbo.Departments', 'U') IS NULL
CREATE TABLE dbo.Departments (
    DepartmentId INT IDENTITY(1,1) CONSTRAINT PK_Departments PRIMARY KEY,
    DepartmentName NVARCHAR(120) NOT NULL CONSTRAINT UQ_Departments_DepartmentName UNIQUE
);",
@"IF OBJECT_ID('dbo.Positions', 'U') IS NULL
CREATE TABLE dbo.Positions (
    PositionId INT IDENTITY(1,1) CONSTRAINT PK_Positions PRIMARY KEY,
    PositionName NVARCHAR(120) NOT NULL CONSTRAINT UQ_Positions_PositionName UNIQUE
);",
@"IF OBJECT_ID('dbo.Employees', 'U') IS NULL
CREATE TABLE dbo.Employees (
    EmployeeId INT IDENTITY(1,1) CONSTRAINT PK_Employees PRIMARY KEY,
    FullName NVARCHAR(150) NOT NULL,
    DepartmentId INT NOT NULL,
    PositionId INT NOT NULL,
    HireDate DATE NOT NULL,
    Contacts NVARCHAR(250) NULL,
    IsDeleted BIT NOT NULL CONSTRAINT DF_Employees_IsDeleted DEFAULT(0),
    CONSTRAINT FK_Employees_Departments FOREIGN KEY (DepartmentId) REFERENCES dbo.Departments(DepartmentId),
    CONSTRAINT FK_Employees_Positions FOREIGN KEY (PositionId) REFERENCES dbo.Positions(PositionId)
);",
@"IF OBJECT_ID('dbo.Salaries', 'U') IS NULL
CREATE TABLE dbo.Salaries (
    SalaryId INT IDENTITY(1,1) CONSTRAINT PK_Salaries PRIMARY KEY,
    EmployeeId INT NOT NULL,
    SalaryAmount DECIMAL(12,2) NOT NULL CONSTRAINT CK_Salaries_Amount CHECK (SalaryAmount >= 0),
    BonusAmount DECIMAL(12,2) NOT NULL CONSTRAINT CK_Salaries_Bonus CHECK (BonusAmount >= 0),
    SalaryDate DATE NOT NULL,
    CONSTRAINT FK_Salaries_Employees FOREIGN KEY (EmployeeId) REFERENCES dbo.Employees(EmployeeId)
);",
@"IF OBJECT_ID('dbo.ChangeRequests', 'U') IS NULL
CREATE TABLE dbo.ChangeRequests (
    RequestId INT IDENTITY(1,1) CONSTRAINT PK_ChangeRequests PRIMARY KEY,
    EmployeeId INT NOT NULL,
    RequestDate DATETIME2 NOT NULL CONSTRAINT DF_ChangeRequests_RequestDate DEFAULT(SYSDATETIME()),
    FieldName NVARCHAR(80) NOT NULL,
    NewValue NVARCHAR(250) NOT NULL,
    RequestStatus NVARCHAR(30) NOT NULL CONSTRAINT DF_ChangeRequests_Status DEFAULT(N'Новая'),
    CONSTRAINT FK_ChangeRequests_Employees FOREIGN KEY (EmployeeId) REFERENCES dbo.Employees(EmployeeId),
    CONSTRAINT CK_ChangeRequests_Status CHECK (RequestStatus IN (N'Новая', N'Одобрена', N'Отклонена'))
);",
@"IF OBJECT_ID('dbo.TurnoverRecords', 'U') IS NULL
CREATE TABLE dbo.TurnoverRecords (
    TurnoverId INT IDENTITY(1,1) CONSTRAINT PK_TurnoverRecords PRIMARY KEY,
    EmployeeId INT NOT NULL,
    EventType NVARCHAR(30) NOT NULL,
    EventDate DATE NOT NULL,
    Comment NVARCHAR(250) NULL,
    CONSTRAINT FK_TurnoverRecords_Employees FOREIGN KEY (EmployeeId) REFERENCES dbo.Employees(EmployeeId),
    CONSTRAINT CK_TurnoverRecords_EventType CHECK (EventType IN (N'Прием', N'Увольнение'))
);",
@"IF OBJECT_ID('dbo.DeletionLog', 'U') IS NULL
CREATE TABLE dbo.DeletionLog (
    LogId INT IDENTITY(1,1) CONSTRAINT PK_DeletionLog PRIMARY KEY,
    EntityName NVARCHAR(80) NOT NULL,
    EntityId INT NOT NULL,
    DeletedAt DATETIME2 NOT NULL CONSTRAINT DF_DeletionLog_DeletedAt DEFAULT(SYSDATETIME()),
    DataSnapshot NVARCHAR(MAX) NOT NULL
);",
@"IF OBJECT_ID('dbo.AppUsers', 'U') IS NULL
CREATE TABLE dbo.AppUsers (
    UserId INT IDENTITY(1,1) CONSTRAINT PK_AppUsers PRIMARY KEY,
    Login NVARCHAR(50) NOT NULL CONSTRAINT UQ_AppUsers_Login UNIQUE,
    UserPassword NVARCHAR(50) NOT NULL,
    UserRole NVARCHAR(30) NOT NULL,
    DisplayName NVARCHAR(150) NOT NULL,
    EmployeeId INT NULL,
    ReaderId INT NULL,
    IsActive BIT NOT NULL CONSTRAINT DF_AppUsers_IsActive DEFAULT(1),
    CONSTRAINT CK_AppUsers_Role CHECK (UserRole IN (N'HR', N'Employee')),
    CONSTRAINT FK_AppUsers_Employees FOREIGN KEY (EmployeeId) REFERENCES dbo.Employees(EmployeeId)
);"
            );
        }

        private static void SeedData()
        {
            using var connection = new SqlConnection(AppConnectionString);
            connection.Open();
            using (var check = new SqlCommand("SELECT COUNT(*) FROM dbo.Employees", connection))
            {
                if ((int)check.ExecuteScalar() > 0) return;
            }

            string seedSql = @"
INSERT INTO dbo.Departments (DepartmentName) VALUES
(N'Отдел разработки'), (N'Отдел кадров'), (N'Бухгалтерия'), (N'Маркетинг'), (N'Техническая поддержка');

INSERT INTO dbo.Positions (PositionName) VALUES
(N'Разработчик'), (N'HR-менеджер'), (N'Бухгалтер'), (N'Аналитик'), (N'Специалист поддержки');

INSERT INTO dbo.Employees (FullName, DepartmentId, PositionId, HireDate, Contacts) VALUES
(N'Александров Иван Петрович 01', 1, 1, DATEADD(DAY, -920, CAST(GETDATE() AS date)), N'ivan.alexandrov@example.local; +7 900 200-01-01'),
(N'Беляева Мария Сергеевна 01', 2, 2, DATEADD(DAY, -760, CAST(GETDATE() AS date)), N'maria.belyaeva@example.local; +7 900 200-01-02'),
(N'Волков Дмитрий Андреевич 01', 3, 3, DATEADD(DAY, -650, CAST(GETDATE() AS date)), N'dmitry.volkov@example.local; +7 900 200-01-03'),
(N'Громова Анна Игоревна 01', 4, 4, DATEADD(DAY, -520, CAST(GETDATE() AS date)), N'anna.gromova@example.local; +7 900 200-01-04'),
(N'Дорофеев Павел Олегович 01', 5, 5, DATEADD(DAY, -430, CAST(GETDATE() AS date)), N'pavel.dorofeev@example.local; +7 900 200-01-05'),
(N'Егорова Елена Николаевна 01', 1, 1, DATEADD(DAY, -350, CAST(GETDATE() AS date)), N'elena.egorova@example.local; +7 900 200-01-11'),
(N'Жуков Максим Романович 01', 4, 4, DATEADD(DAY, -270, CAST(GETDATE() AS date)), N'maxim.zhukov@example.local; +7 900 200-01-07'),
(N'Зайцева Ольга Павловна 01', 3, 3, DATEADD(DAY, -210, CAST(GETDATE() AS date)), N'olga.zaitseva@example.local; +7 900 200-01-08'),
(N'Кириллов Никита Денисович 01', 5, 5, DATEADD(DAY, -150, CAST(GETDATE() AS date)), N'nikita.kirillov@example.local; +7 900 200-01-09'),
(N'Лебедева Софья Михайловна 01', 2, 2, DATEADD(DAY, -80, CAST(GETDATE() AS date)), N'sofia.lebedeva@example.local; +7 900 200-01-10');

INSERT INTO dbo.Salaries (EmployeeId, SalaryAmount, BonusAmount, SalaryDate) VALUES
(1, 115000, 15000, CAST(GETDATE() AS date)),
(2, 82000, 9000, CAST(GETDATE() AS date)),
(3, 90000, 12000, CAST(GETDATE() AS date)),
(4, 95000, 11000, CAST(GETDATE() AS date)),
(5, 70000, 6000, CAST(GETDATE() AS date)),
(6, 118000, 16000, CAST(GETDATE() AS date)),
(7, 97000, 10000, CAST(GETDATE() AS date)),
(8, 88000, 8000, CAST(GETDATE() AS date)),
(9, 68000, 5000, CAST(GETDATE() AS date)),
(10, 83000, 9000, CAST(GETDATE() AS date));

INSERT INTO dbo.ChangeRequests (EmployeeId, FieldName, NewValue, RequestStatus) VALUES
(1, N'Контакты', N'ivan.new@example.local', N'Новая'),
(4, N'Контакты', N'+7 900 300-11-44', N'Одобрена'),
(7, N'Контакты', N'maxim.updated@example.local', N'Отклонена');

INSERT INTO dbo.TurnoverRecords (EmployeeId, EventType, EventDate, Comment) VALUES
(1, N'Прием', DATEADD(DAY, -920, CAST(GETDATE() AS date)), N'Принят в отдел разработки'),
(2, N'Прием', DATEADD(DAY, -760, CAST(GETDATE() AS date)), N'Принята в отдел кадров'),
(3, N'Прием', DATEADD(DAY, -650, CAST(GETDATE() AS date)), N'Принят в бухгалтерию'),
(4, N'Прием', DATEADD(DAY, -520, CAST(GETDATE() AS date)), N'Принята в маркетинг'),
(5, N'Прием', DATEADD(DAY, -430, CAST(GETDATE() AS date)), N'Принят в поддержку'),
(9, N'Увольнение', DATEADD(DAY, -20, CAST(GETDATE() AS date)), N'Тестовая запись для отчета по текучести');
";
            using var cmd = new SqlCommand(seedSql, connection);
            cmd.ExecuteNonQuery();
        }

        private static void SeedAuthUsers()
        {
            using var connection = new SqlConnection(AppConnectionString);
            connection.Open();
            string sql = @"
DECLARE @emp1 INT = (SELECT EmployeeId FROM (SELECT EmployeeId, ROW_NUMBER() OVER (ORDER BY EmployeeId) AS rn FROM dbo.Employees WHERE IsDeleted=0) x WHERE rn=1);
DECLARE @emp2 INT = (SELECT EmployeeId FROM (SELECT EmployeeId, ROW_NUMBER() OVER (ORDER BY EmployeeId) AS rn FROM dbo.Employees WHERE IsDeleted=0) x WHERE rn=4);
DECLARE @emp3 INT = (SELECT EmployeeId FROM (SELECT EmployeeId, ROW_NUMBER() OVER (ORDER BY EmployeeId) AS rn FROM dbo.Employees WHERE IsDeleted=0) x WHERE rn=7);

IF NOT EXISTS (SELECT 1 FROM dbo.AppUsers WHERE Login=N'hr')
    INSERT INTO dbo.AppUsers(Login, UserPassword, UserRole, DisplayName, EmployeeId) VALUES (N'hr', N'123', N'HR', N'HR-менеджер', NULL);

IF @emp1 IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.AppUsers WHERE Login=N'emp1')
    INSERT INTO dbo.AppUsers(Login, UserPassword, UserRole, DisplayName, EmployeeId) SELECT N'emp1', N'123', N'Employee', FullName, EmployeeId FROM dbo.Employees WHERE EmployeeId=@emp1;

IF @emp2 IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.AppUsers WHERE Login=N'emp2')
    INSERT INTO dbo.AppUsers(Login, UserPassword, UserRole, DisplayName, EmployeeId) SELECT N'emp2', N'123', N'Employee', FullName, EmployeeId FROM dbo.Employees WHERE EmployeeId=@emp2;

IF @emp3 IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.AppUsers WHERE Login=N'emp3')
    INSERT INTO dbo.AppUsers(Login, UserPassword, UserRole, DisplayName, EmployeeId) SELECT N'emp3', N'123', N'Employee', FullName, EmployeeId FROM dbo.Employees WHERE EmployeeId=@emp3;
";
            using var command = new SqlCommand(sql, connection);
            command.ExecuteNonQuery();
        }

    }
}
