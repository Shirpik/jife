using System;

namespace DemoExam_V1_13
{
    public sealed class CurrentUser
    {
        public int UserId { get; set; }
        public string Login { get; set; } = string.Empty;
        public string Role { get; set; } = string.Empty;
        public string DisplayName { get; set; } = string.Empty;
        public int? EmployeeId { get; set; }
        public int? ReaderId { get; set; }

        public bool IsHr => string.Equals(Role, "HR", StringComparison.OrdinalIgnoreCase);
        public bool IsEmployee => string.Equals(Role, "Employee", StringComparison.OrdinalIgnoreCase);
        public bool IsLibrarian => string.Equals(Role, "Librarian", StringComparison.OrdinalIgnoreCase);
        public bool IsReader => string.Equals(Role, "Reader", StringComparison.OrdinalIgnoreCase);

        public string RoleTitle => Role switch
        {
            "HR" => "HR-менеджер",
            "Employee" => "Сотрудник",
            "Librarian" => "Библиотекарь",
            "Reader" => "Читатель",
            _ => Role
        };
    }
}
