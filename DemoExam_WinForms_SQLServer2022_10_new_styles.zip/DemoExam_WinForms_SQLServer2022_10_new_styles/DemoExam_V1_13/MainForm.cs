using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace DemoExam_V1_13
{
    public class MainForm : Form
    {
        private readonly CurrentUser _user;
        private DataGridView gridBooks;
        private TextBox txtBookTitle;
        private NumericUpDown numBookYear;
        private ComboBox cmbAuthor;
        private ComboBox cmbGenre;
        private ComboBox cmbStatus;

        private DataGridView gridReaders;
        private DataGridView gridReaderLoans;

        private ComboBox cmbReaderSelf;
        private DataGridView gridMyLoans;
        private DataGridView gridAvailableBooks;

        private ComboBox cmbDashStatus;
        private ComboBox cmbDashAuthor;
        private DataGridView gridDashboard;
        private Panel panelChart;
        private DataTable chartData;

        public MainForm(CurrentUser user)
        {
            _user = user;
            Text = "Вариант №1. Библиотека. Комплект 13 | SQL Server: " + DatabaseInitializer.ServerName + " | БД: " + DatabaseInitializer.DatabaseName + " | Пользователь: " + _user.DisplayName + " (" + _user.RoleTitle + ")";
            Width = 1200;
            Height = 780;
            StartPosition = FormStartPosition.CenterScreen;
            Font = new Font("Segoe UI", 10F);

            var tabs = new TabControl { Dock = DockStyle.Fill };
            if (_user.IsLibrarian)
            {
                tabs.TabPages.Add(BuildBooksTab());
                tabs.TabPages.Add(BuildReadersTab());
                tabs.TabPages.Add(BuildDashboardTab());
            }
            if (_user.IsReader)
            {
                tabs.TabPages.Add(BuildReaderFunctionsTab());
            }
            UiTheme.BuildMainShell(this, tabs, "Вариант №1 - библиотека", "Роль: " + _user.RoleTitle + " | Пользователь: " + _user.DisplayName);

            LoadDictionaries();
            if (_user.IsLibrarian)
            {
                LoadBooks();
                LoadReaders();
                LoadDashboard();
            }
            if (_user.IsReader)
            {
                LoadReaderSelf();
            }
        }

        private TabPage BuildBooksTab()
        {
            var page = new TabPage("Библиотекарь: книги");
            var split = new SplitContainer { Dock = DockStyle.Fill, Orientation = Orientation.Horizontal, SplitterDistance = 185, FixedPanel = FixedPanel.Panel1 };
            var form = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 6, RowCount = 3, Padding = new Padding(12) };
            form.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 85));
            form.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 36));
            form.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 70));
            form.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 22));
            form.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 75));
            form.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 42));
            form.RowStyles.Add(new RowStyle(SizeType.Absolute, 42));
            form.RowStyles.Add(new RowStyle(SizeType.Absolute, 42));
            form.RowStyles.Add(new RowStyle(SizeType.Absolute, 52));

            txtBookTitle = new TextBox { Dock = DockStyle.Fill, PlaceholderText = "Название книги" };
            numBookYear = new NumericUpDown { Dock = DockStyle.Fill, Minimum = 1400, Maximum = 2100, Value = DateTime.Today.Year };
            cmbAuthor = new ComboBox { Dock = DockStyle.Fill, DropDownStyle = ComboBoxStyle.DropDownList };
            cmbGenre = new ComboBox { Dock = DockStyle.Fill, DropDownStyle = ComboBoxStyle.DropDownList };
            cmbStatus = new ComboBox { Dock = DockStyle.Fill, DropDownStyle = ComboBoxStyle.DropDownList };
            cmbStatus.Items.AddRange(new object[] { "В наличии", "Выдана", "Списана" });
            cmbStatus.SelectedIndex = 0;

            var btnAdd = new Button { Text = "Добавить", Width = 130, Height = 34 };
            var btnUpdate = new Button { Text = "Изменить", Width = 130, Height = 34 };
            var btnDelete = new Button { Text = "Мягко удалить", Width = 150, Height = 34 };
            var btnRefresh = new Button { Text = "Обновить", Width = 130, Height = 34 };
            btnAdd.Click += (s, e) => AddBook();
            btnUpdate.Click += (s, e) => UpdateBook();
            btnDelete.Click += (s, e) => DeleteBook();
            btnRefresh.Click += (s, e) => LoadBooks();

            var buttonsPanel = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.LeftToRight, WrapContents = false, AutoScroll = true, Padding = new Padding(0, 8, 0, 0) };
            buttonsPanel.Controls.AddRange(new Control[] { btnAdd, btnUpdate, btnDelete, btnRefresh });

            form.Controls.Add(new Label { Text = "Название:", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 0, 0);
            form.Controls.Add(txtBookTitle, 1, 0);
            form.Controls.Add(new Label { Text = "Год:", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 2, 0);
            form.Controls.Add(numBookYear, 3, 0);
            form.Controls.Add(new Label { Text = "Автор:", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 4, 0);
            form.Controls.Add(cmbAuthor, 5, 0);
            form.Controls.Add(new Label { Text = "Жанр:", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 0, 1);
            form.Controls.Add(cmbGenre, 1, 1);
            form.Controls.Add(new Label { Text = "Статус:", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 2, 1);
            form.Controls.Add(cmbStatus, 3, 1);
            form.Controls.Add(buttonsPanel, 0, 2);
            form.SetColumnSpan(buttonsPanel, 6);

            gridBooks = NewGrid();
            gridBooks.SelectionChanged += (s, e) => FillBookFieldsFromGrid();
            split.Panel1.Controls.Add(form);
            split.Panel2.Controls.Add(gridBooks);
            page.Controls.Add(split);
            return page;
        }

        private TabPage BuildReadersTab()
        {
            var page = new TabPage("Библиотекарь: читатели и задолженности");
            var split = new SplitContainer { Dock = DockStyle.Fill, Orientation = Orientation.Vertical, SplitterDistance = 520 };
            gridReaders = NewGrid();
            gridReaders.SelectionChanged += (s, e) => LoadLoansBySelectedReader();
            gridReaderLoans = NewGrid();
            split.Panel1.Controls.Add(gridReaders);
            split.Panel2.Controls.Add(gridReaderLoans);

            var top = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 50, FlowDirection = FlowDirection.LeftToRight, WrapContents = false, AutoScroll = true, Padding = new Padding(8) };
            var btnRefresh = new Button { Text = "Обновить", Width = 110 };
            btnRefresh.Click += (s, e) => LoadReaders();
            top.Controls.Add(btnRefresh);
            page.Controls.Add(split);
            page.Controls.Add(top);
            return page;
        }

        private TabPage BuildReaderFunctionsTab()
        {
            var page = new TabPage("Читатель");
            var layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 4 };
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 55));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 45));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 45));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 55));

            var top = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.LeftToRight, WrapContents = false, AutoScroll = true, Padding = new Padding(8) };
            cmbReaderSelf = new ComboBox { Width = 320, DropDownStyle = ComboBoxStyle.DropDownList };
            var btnLoad = new Button { Text = "Показать мои книги", Width = 160 };
            var btnRequest = new Button { Text = "Запросить продление", Width = 185 };
            btnLoad.Click += (s, e) => LoadMyLoans();
            btnRequest.Click += (s, e) => CreateExtensionRequest();
            top.Controls.AddRange(new Control[] { new Label { Text = "Читатель:", AutoSize = true, Padding = new Padding(0, 7, 0, 0) }, cmbReaderSelf, btnLoad, btnRequest });

            gridMyLoans = NewGrid();
            gridAvailableBooks = NewGrid();
            var lblAvailable = new Label { Text = "Доступные книги в библиотеке", Dock = DockStyle.Fill, Padding = new Padding(8, 10, 0, 0), Font = new Font(Font, FontStyle.Bold) };
            layout.Controls.Add(top, 0, 0);
            layout.Controls.Add(gridMyLoans, 0, 1);
            layout.Controls.Add(lblAvailable, 0, 2);
            layout.Controls.Add(gridAvailableBooks, 0, 3);
            page.Controls.Add(layout);
            return page;
        }

        private TabPage BuildDashboardTab()
        {
            var page = new TabPage("Интерактивный дашборд");
            var layout = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 3, ColumnCount = 1 };
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 55));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 45));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 55));

            var filters = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.LeftToRight, WrapContents = false, AutoScroll = true, Padding = new Padding(8) };
            cmbDashStatus = new ComboBox { Width = 150, DropDownStyle = ComboBoxStyle.DropDownList };
            cmbDashStatus.Items.AddRange(new object[] { "Все", "В наличии", "Выдана", "Списана" });
            cmbDashStatus.SelectedIndex = 0;
            cmbDashAuthor = new ComboBox { Width = 240, DropDownStyle = ComboBoxStyle.DropDownList };
            var btnRefresh = new Button { Text = "Обновить дашборд", Width = 160 };
            btnRefresh.Click += (s, e) => LoadDashboard();
            cmbDashStatus.SelectedIndexChanged += (s, e) => LoadDashboard();
            cmbDashAuthor.SelectedIndexChanged += (s, e) => LoadDashboard();
            filters.Controls.AddRange(new Control[] {
                new Label { Text = "Статус:", AutoSize = true, Padding = new Padding(0, 7, 0, 0) }, cmbDashStatus,
                new Label { Text = "Автор:", AutoSize = true, Padding = new Padding(0, 7, 0, 0) }, cmbDashAuthor,
                btnRefresh
            });

            panelChart = new Panel { Dock = DockStyle.Fill, BackColor = UiTheme.CardBack, BorderStyle = BorderStyle.FixedSingle };
            panelChart.Paint += (s, e) => DrawBarChart(e.Graphics, chartData, "GenreName", "BookCount", "Количество книг по жанрам");
            gridDashboard = NewGrid();
            layout.Controls.Add(filters, 0, 0);
            layout.Controls.Add(panelChart, 0, 1);
            layout.Controls.Add(gridDashboard, 0, 2);
            page.Controls.Add(layout);
            return page;
        }

        private DataGridView NewGrid()
        {
            return new DataGridView
            {
                Dock = DockStyle.Fill,
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false
            };
        }

        private void LoadDictionaries()
        {
            if (cmbAuthor != null)
                FillCombo(cmbAuthor, "SELECT AuthorId AS Id, FullName AS Text FROM dbo.Authors ORDER BY FullName");
            if (cmbGenre != null)
                FillCombo(cmbGenre, "SELECT GenreId AS Id, GenreName AS Text FROM dbo.Genres ORDER BY GenreName");
            if (cmbDashAuthor != null)
                FillCombo(cmbDashAuthor, "SELECT 0 AS Id, N'Все' AS Text UNION ALL SELECT AuthorId, FullName FROM dbo.Authors ORDER BY Text");
        }

        private void FillCombo(ComboBox combo, string sql)
        {
            if (combo == null) return;
            combo.Items.Clear();
            foreach (DataRow row in Db.Query(sql).Rows)
                combo.Items.Add(new ComboItem { Id = Convert.ToInt32(row["Id"]), Text = Convert.ToString(row["Text"]) });
            if (combo.Items.Count > 0) combo.SelectedIndex = 0;
        }

        private int SelectedComboId(ComboBox combo)
        {
            return combo.SelectedItem is ComboItem item ? item.Id : 0;
        }

        private int? SelectedGridId(DataGridView grid)
        {
            if (grid.CurrentRow == null || grid.CurrentRow.Cells["Id"] == null) return null;
            return Convert.ToInt32(grid.CurrentRow.Cells["Id"].Value);
        }

        private void LoadBooks()
        {
            gridBooks.DataSource = Db.Query(@"
SELECT b.BookId AS Id, b.Title AS [Название], a.FullName AS [Автор], g.GenreName AS [Жанр],
       b.PublishYear AS [Год], b.BookStatus AS [Статус]
FROM dbo.Books b
JOIN dbo.Authors a ON a.AuthorId = b.AuthorId
JOIN dbo.Genres g ON g.GenreId = b.GenreId
WHERE b.IsDeleted = 0
ORDER BY b.Title");
            HideId(gridBooks);
        }

        private void FillBookFieldsFromGrid()
        {
            if (gridBooks.CurrentRow == null) return;
            txtBookTitle.Text = Convert.ToString(gridBooks.CurrentRow.Cells["Название"].Value);
            if (int.TryParse(Convert.ToString(gridBooks.CurrentRow.Cells["Год"].Value), out int year)) numBookYear.Value = year;
            cmbStatus.SelectedItem = Convert.ToString(gridBooks.CurrentRow.Cells["Статус"].Value);
            SelectComboByText(cmbAuthor, Convert.ToString(gridBooks.CurrentRow.Cells["Автор"].Value));
            SelectComboByText(cmbGenre, Convert.ToString(gridBooks.CurrentRow.Cells["Жанр"].Value));
        }

        private void SelectComboByText(ComboBox combo, string text)
        {
            for (int i = 0; i < combo.Items.Count; i++)
                if (combo.Items[i].ToString() == text) { combo.SelectedIndex = i; return; }
        }

        private void AddBook()
        {
            if (string.IsNullOrWhiteSpace(txtBookTitle.Text)) { MessageBox.Show("Введите название книги."); return; }
            Db.Execute(@"INSERT INTO dbo.Books (Title, AuthorId, GenreId, PublishYear, BookStatus) VALUES (@t, @a, @g, @y, @s)",
                Db.P("@t", txtBookTitle.Text.Trim()), Db.P("@a", SelectedComboId(cmbAuthor)), Db.P("@g", SelectedComboId(cmbGenre)), Db.P("@y", (int)numBookYear.Value), Db.P("@s", cmbStatus.Text));
            LoadBooks(); LoadDashboard();
        }

        private void UpdateBook()
        {
            var id = SelectedGridId(gridBooks);
            if (id == null) { MessageBox.Show("Выберите книгу."); return; }
            Db.Execute(@"UPDATE dbo.Books SET Title=@t, AuthorId=@a, GenreId=@g, PublishYear=@y, BookStatus=@s WHERE BookId=@id",
                Db.P("@t", txtBookTitle.Text.Trim()), Db.P("@a", SelectedComboId(cmbAuthor)), Db.P("@g", SelectedComboId(cmbGenre)), Db.P("@y", (int)numBookYear.Value), Db.P("@s", cmbStatus.Text), Db.P("@id", id.Value));
            LoadBooks(); LoadDashboard();
        }

        private void DeleteBook()
        {
            var id = SelectedGridId(gridBooks);
            if (id == null) { MessageBox.Show("Выберите книгу."); return; }
            if (MessageBox.Show("Книга будет скрыта, но запись сохранится для просмотра и восстановления. Продолжить?", "Мягкое удаление", MessageBoxButtons.YesNo) != DialogResult.Yes) return;
            Db.Execute(@"INSERT INTO dbo.DeletionLog(EntityName, EntityId, DataSnapshot)
                         SELECT N'Books', BookId, CONCAT(Title, N'; ', BookStatus) FROM dbo.Books WHERE BookId=@id;
                         UPDATE dbo.Books SET IsDeleted=1 WHERE BookId=@id;", Db.P("@id", id.Value));
            LoadBooks(); LoadDashboard();
        }

        private void LoadReaders()
        {
            gridReaders.DataSource = Db.Query(@"
SELECT r.ReaderId AS Id, r.FullName AS [ФИО], r.Phone AS [Телефон], r.Email AS [Email],
       SUM(CASE WHEN l.ReturnDate IS NULL AND l.DueDate < CAST(GETDATE() AS date) THEN 1 ELSE 0 END) AS [Активные задолженности]
FROM dbo.Readers r
LEFT JOIN dbo.Loans l ON l.ReaderId = r.ReaderId
WHERE r.IsDeleted = 0
GROUP BY r.ReaderId, r.FullName, r.Phone, r.Email
ORDER BY r.FullName");
            HideId(gridReaders);
            LoadLoansBySelectedReader();
        }

        private void LoadLoansBySelectedReader()
        {
            var id = SelectedGridId(gridReaders);
            if (id == null) return;
            gridReaderLoans.DataSource = Db.Query(@"
SELECT l.LoanId AS Id, b.Title AS [Книга], l.IssueDate AS [Дата выдачи], l.DueDate AS [Срок возврата],
       CASE WHEN l.ReturnDate IS NULL AND l.DueDate < CAST(GETDATE() AS date) THEN N'Просрочена' ELSE N'Активна' END AS [Состояние]
FROM dbo.Loans l
JOIN dbo.Books b ON b.BookId = l.BookId
WHERE l.ReaderId=@readerId AND l.ReturnDate IS NULL
ORDER BY l.DueDate", Db.P("@readerId", id.Value));
            HideId(gridReaderLoans);
        }

        private void LoadReaderSelf()
        {
            if (cmbReaderSelf == null) return;
            if (_user.IsReader && _user.ReaderId.HasValue)
            {
                FillCombo(cmbReaderSelf, $"SELECT ReaderId AS Id, FullName AS Text FROM dbo.Readers WHERE IsDeleted=0 AND ReaderId={_user.ReaderId.Value}");
                cmbReaderSelf.Enabled = false;
            }
            else
            {
                FillCombo(cmbReaderSelf, "SELECT ReaderId AS Id, FullName AS Text FROM dbo.Readers WHERE IsDeleted=0 ORDER BY FullName");
            }
            LoadMyLoans();
        }

        private void LoadMyLoans()
        {
            if (cmbReaderSelf == null || gridMyLoans == null || gridAvailableBooks == null) return;
            int readerId = SelectedComboId(cmbReaderSelf);
            if (readerId <= 0) return;
            gridMyLoans.DataSource = Db.Query(@"
SELECT l.LoanId AS Id, b.Title AS [Книга], l.IssueDate AS [Дата выдачи], l.DueDate AS [Срок возврата],
       CASE WHEN l.DueDate < CAST(GETDATE() AS date) THEN N'Просрочена' ELSE N'Активна' END AS [Статус]
FROM dbo.Loans l
JOIN dbo.Books b ON b.BookId = l.BookId
WHERE l.ReaderId=@readerId AND l.ReturnDate IS NULL
ORDER BY l.DueDate", Db.P("@readerId", readerId));
            HideId(gridMyLoans);

            gridAvailableBooks.DataSource = Db.Query(@"
SELECT b.BookId AS Id, b.Title AS [Название], a.FullName AS [Автор], g.GenreName AS [Жанр], b.PublishYear AS [Год]
FROM dbo.Books b
JOIN dbo.Authors a ON a.AuthorId = b.AuthorId
JOIN dbo.Genres g ON g.GenreId = b.GenreId
WHERE b.IsDeleted=0 AND b.BookStatus=N'В наличии'
ORDER BY b.Title");
            HideId(gridAvailableBooks);
        }

        private void CreateExtensionRequest()
        {
            var loanId = SelectedGridId(gridMyLoans);
            if (loanId == null) { MessageBox.Show("Выберите книгу из списка активных выдач."); return; }
            Db.Execute(@"INSERT INTO dbo.ExtensionRequests(LoanId, RequestedDueDate)
                         SELECT LoanId, DATEADD(DAY, 14, DueDate) FROM dbo.Loans WHERE LoanId=@loanId", Db.P("@loanId", loanId.Value));
            MessageBox.Show("Запрос на продление создан.");
        }

        private void LoadDashboard()
        {
            if (cmbDashStatus == null || cmbDashAuthor == null) return;
            string status = cmbDashStatus.Text;
            int authorId = SelectedComboId(cmbDashAuthor);

            var parameters = new List<Microsoft.Data.SqlClient.SqlParameter>();
            string where = "WHERE b.IsDeleted=0";
            if (status != "Все") { where += " AND b.BookStatus=@status"; parameters.Add(Db.P("@status", status)); }
            if (authorId > 0) { where += " AND b.AuthorId=@author"; parameters.Add(Db.P("@author", authorId)); }

            chartData = Db.Query($@"
SELECT g.GenreName, COUNT(*) AS BookCount
FROM dbo.Books b
JOIN dbo.Genres g ON g.GenreId=b.GenreId
{where}
GROUP BY g.GenreName
ORDER BY g.GenreName", parameters.ToArray());

            gridDashboard.DataSource = Db.Query($@"
SELECT b.Title AS [Название], a.FullName AS [Автор], g.GenreName AS [Жанр], b.PublishYear AS [Год], b.BookStatus AS [Статус]
FROM dbo.Books b
JOIN dbo.Authors a ON a.AuthorId=b.AuthorId
JOIN dbo.Genres g ON g.GenreId=b.GenreId
{where}
ORDER BY b.Title", parameters.ToArray());
            panelChart?.Invalidate();
        }

        private void DrawBarChart(Graphics g, DataTable data, string labelColumn, string valueColumn, string title)
        {
            g.Clear(UiTheme.CardBack);
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            using var titleFont = new Font(Font.FontFamily, 12F, FontStyle.Bold);
            g.DrawString(title, titleFont, UiTheme.TextBrush, 12, 10);
            if (data == null || data.Rows.Count == 0)
            {
                g.DrawString("Нет данных для выбранного фильтра", Font, UiTheme.MutedBrush, 12, 45);
                return;
            }
            int left = 50, top = 55, bottom = panelChart.Height - 45, right = panelChart.Width - 25;
            int chartHeight = Math.Max(10, bottom - top);
            int chartWidth = Math.Max(10, right - left);
            int max = data.AsEnumerable().Max(r => Convert.ToInt32(r[valueColumn]));
            int barWidth = Math.Max(20, chartWidth / data.Rows.Count - 18);
            g.DrawLine(UiTheme.AxisPen, left, top, left, bottom);
            g.DrawLine(UiTheme.AxisPen, left, bottom, right, bottom);
            for (int i = 0; i < data.Rows.Count; i++)
            {
                string label = Convert.ToString(data.Rows[i][labelColumn]);
                int value = Convert.ToInt32(data.Rows[i][valueColumn]);
                int barHeight = (int)(chartHeight * (value / (double)Math.Max(1, max)));
                int x = left + 12 + i * (barWidth + 18);
                int y = bottom - barHeight;
                g.FillRectangle(UiTheme.ChartBrush, x, y, barWidth, barHeight);
                g.DrawRectangle(UiTheme.ChartPen, x, y, barWidth, barHeight);
                g.DrawString(value.ToString(), Font, UiTheme.TextBrush, x + barWidth / 3, y - 22);
                string shortLabel = label.Length > 14 ? label.Substring(0, 14) + "..." : label;
                g.DrawString(shortLabel, Font, UiTheme.TextBrush, x - 5, bottom + 5);
            }
        }

        private void HideId(DataGridView grid)
        {
            if (grid.Columns.Contains("Id")) grid.Columns["Id"].Visible = false;
        }
    }
}
