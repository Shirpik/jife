/*
Этот проект создает базу данных автоматически при запуске.
Основной SQL-код находится в файле DatabaseInitializer.cs.

База данных: DemoExam_V3_13
Серверы, которые приложение пробует при запуске:
1) .\SQLEXPRESS
2) (localdb)\MSSQLLocalDB
3) localhost

Для ручной проверки после запуска используйте SQL Server Management Studio:
SELECT name FROM sys.databases WHERE name = N'DemoExam_V3_13';
*/
