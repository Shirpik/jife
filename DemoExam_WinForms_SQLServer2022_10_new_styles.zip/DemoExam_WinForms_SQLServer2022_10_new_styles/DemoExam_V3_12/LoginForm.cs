using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace DemoExam_V3_12
{
    public sealed class LoginForm : Form
    {
        private readonly ComboBox cmbDemoUsers;
        private readonly TextBox txtLogin;
        private readonly TextBox txtPassword;
        private readonly Label lblInfo;
        private readonly CheckBox chkShowPassword;

        public CurrentUser AuthenticatedUser { get; private set; }

        public LoginForm()
        {
            Text = "Авторизация";
            Width = 520;
            Height = 360;
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            Font = new Font("Segoe UI", 10F);

            var panel = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 2,
                RowCount = 8,
                Padding = new Padding(18)
            };
            panel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 150));
            panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 38));
            panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 42));
            panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 42));
            panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 42));
            panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 36));
            panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 48));
            panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 42));
            panel.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

            var title = new Label
            {
                Text = "Вход в систему",
                Dock = DockStyle.Fill,
                Font = new Font(Font.FontFamily, 14F, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleLeft
            };
            panel.Controls.Add(title, 0, 0);
            panel.SetColumnSpan(title, 2);

            cmbDemoUsers = new ComboBox { Dock = DockStyle.Fill, DropDownStyle = ComboBoxStyle.DropDownList };
            cmbDemoUsers.SelectedIndexChanged += (s, e) => ApplySelectedDemoUser();
            panel.Controls.Add(new Label { Text = "Демо-пользователь:", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 0, 1);
            panel.Controls.Add(cmbDemoUsers, 1, 1);

            txtLogin = new TextBox { Dock = DockStyle.Fill };
            panel.Controls.Add(new Label { Text = "Логин:", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 0, 2);
            panel.Controls.Add(txtLogin, 1, 2);

            txtPassword = new TextBox { Dock = DockStyle.Fill, PasswordChar = '*' };
            panel.Controls.Add(new Label { Text = "Пароль:", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 0, 3);
            panel.Controls.Add(txtPassword, 1, 3);

            chkShowPassword = new CheckBox { Text = "Показать пароль", Dock = DockStyle.Fill };
            chkShowPassword.CheckedChanged += (s, e) => txtPassword.PasswordChar = chkShowPassword.Checked ? '\0' : '*';
            panel.Controls.Add(new Label(), 0, 4);
            panel.Controls.Add(chkShowPassword, 1, 4);

            lblInfo = new Label
            {
                Text = "Выберите пользователя из списка или введите логин и пароль вручную.",
                Dock = DockStyle.Fill,
                AutoEllipsis = true,
                TextAlign = ContentAlignment.MiddleLeft
            };
            panel.Controls.Add(lblInfo, 0, 5);
            panel.SetColumnSpan(lblInfo, 2);

            var buttons = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft };
            var btnLogin = new Button { Text = "Войти", Width = 120, Height = 34 };
            var btnCancel = new Button { Text = "Отмена", Width = 120, Height = 34, DialogResult = DialogResult.Cancel };
            btnLogin.Click += (s, e) => TryLogin();
            buttons.Controls.Add(btnLogin);
            buttons.Controls.Add(btnCancel);
            panel.Controls.Add(buttons, 0, 6);
            panel.SetColumnSpan(buttons, 2);

            AcceptButton = btnLogin;
            CancelButton = btnCancel;
            Controls.Add(panel);
            UiTheme.ApplyLogin(this, "Авторизация", "Демо-вход");

            Load += (s, e) => LoadDemoUsers();
        }

        private void LoadDemoUsers()
        {
            cmbDemoUsers.Items.Clear();
            DataTable users = Db.Query(@"
SELECT UserId, Login, UserPassword, UserRole, DisplayName, EmployeeId, ReaderId
FROM dbo.AppUsers
WHERE IsActive = 1
ORDER BY CASE UserRole WHEN N'HR' THEN 1 WHEN N'Librarian' THEN 1 WHEN N'Employee' THEN 2 WHEN N'Reader' THEN 2 ELSE 3 END, Login");

            foreach (DataRow row in users.Rows)
            {
                cmbDemoUsers.Items.Add(new LoginUserItem
                {
                    Login = Convert.ToString(row["Login"]),
                    Password = Convert.ToString(row["UserPassword"]),
                    Role = Convert.ToString(row["UserRole"]),
                    DisplayName = Convert.ToString(row["DisplayName"])
                });
            }

            if (cmbDemoUsers.Items.Count > 0)
                cmbDemoUsers.SelectedIndex = 0;
        }

        private void ApplySelectedDemoUser()
        {
            if (cmbDemoUsers.SelectedItem is not LoginUserItem item) return;
            txtLogin.Text = item.Login;
            txtPassword.Text = item.Password;
            lblInfo.Text = $"Роль: {RoleTitle(item.Role)}. Можно сразу нажать «Войти».";
        }

        private void TryLogin()
        {
            if (string.IsNullOrWhiteSpace(txtLogin.Text) || string.IsNullOrWhiteSpace(txtPassword.Text))
            {
                MessageBox.Show("Введите логин и пароль.", "Авторизация", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DataTable table = Db.Query(@"
SELECT TOP 1 UserId, Login, UserRole, DisplayName, EmployeeId, ReaderId
FROM dbo.AppUsers
WHERE Login=@login AND UserPassword=@password AND IsActive=1",
                Db.P("@login", txtLogin.Text.Trim()),
                Db.P("@password", txtPassword.Text));

            if (table.Rows.Count == 0)
            {
                MessageBox.Show("Неверный логин или пароль.", "Авторизация", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            DataRow row = table.Rows[0];
            AuthenticatedUser = new CurrentUser
            {
                UserId = Convert.ToInt32(row["UserId"]),
                Login = Convert.ToString(row["Login"]),
                Role = Convert.ToString(row["UserRole"]),
                DisplayName = Convert.ToString(row["DisplayName"]),
                EmployeeId = ToNullableInt(row["EmployeeId"]),
                ReaderId = ToNullableInt(row["ReaderId"])
            };

            DialogResult = DialogResult.OK;
            Close();
        }

        private static int? ToNullableInt(object value)
        {
            return value == DBNull.Value || value == null ? null : Convert.ToInt32(value);
        }

        private static string RoleTitle(string role)
        {
            return role switch
            {
                "HR" => "HR-менеджер",
                "Employee" => "Сотрудник",
                "Librarian" => "Библиотекарь",
                "Reader" => "Читатель",
                _ => role
            };
        }
    }

    internal sealed class LoginUserItem
    {
        public string Login { get; set; }
        public string Password { get; set; }
        public string Role { get; set; }
        public string DisplayName { get; set; }

        public override string ToString()
        {
            string roleTitle = Role switch
            {
                "HR" => "HR-менеджер",
                "Employee" => "Сотрудник",
                "Librarian" => "Библиотекарь",
                "Reader" => "Читатель",
                _ => Role
            };
            return $"{roleTitle}: {DisplayName} ({Login})";
        }
    }
}
