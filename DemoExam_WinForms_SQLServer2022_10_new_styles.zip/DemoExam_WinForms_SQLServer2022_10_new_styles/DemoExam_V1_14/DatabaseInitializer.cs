using System;
using System.Data;
using Microsoft.Data.SqlClient;

namespace DemoExam_V1_14
{
    public static class DatabaseInitializer
    {
        public const string DatabaseName = "DemoExam_V1_14";
        private static readonly string[] ServerCandidates = { @".\SQLEXPRESS", @"(localdb)\MSSQLLocalDB", "localhost" };
        public static string ServerName { get; private set; } = @".\SQLEXPRESS";
        public static string AppConnectionString => $"Data Source={ServerName};Initial Catalog={DatabaseName};Integrated Security=True;TrustServerCertificate=True;Encrypt=False";
        private static string MasterConnectionString => $"Data Source={ServerName};Initial Catalog=master;Integrated Security=True;TrustServerCertificate=True;Encrypt=False";

        public static void EnsureDatabase()
        {
            Exception lastError = null;
            foreach (var server in ServerCandidates)
            {
                try
                {
                    ServerName = server;
                    using (var connection = new SqlConnection(MasterConnectionString))
                    using (var command = connection.CreateCommand())
                    {
                        connection.Open();
                        command.CommandText = $"IF DB_ID(N'{DatabaseName.Replace("'", "''")}') IS NULL CREATE DATABASE [{DatabaseName}]";
                        command.ExecuteNonQuery();
                    }
                    CreateSchema();
                    SeedData();
                    SeedAuthUsers();
                    return;
                }
                catch (Exception ex)
                {
                    lastError = ex;
                }
            }
            throw new InvalidOperationException("Не удалось подключиться ни к одному SQL Server из списка.", lastError);
        }

        private static void ExecuteBatch(params string[] commands)
        {
            using var connection = new SqlConnection(AppConnectionString);
            connection.Open();
            foreach (var sql in commands)
            {
                using var command = new SqlCommand(sql, connection);
                command.ExecuteNonQuery();
            }
        }

        private static void CreateSchema()
        {
            ExecuteBatch(
@"IF OBJECT_ID('dbo.Genres', 'U') IS NULL
CREATE TABLE dbo.Genres (
    GenreId INT IDENTITY(1,1) CONSTRAINT PK_Genres PRIMARY KEY,
    GenreName NVARCHAR(100) NOT NULL CONSTRAINT UQ_Genres_GenreName UNIQUE
);",
@"IF OBJECT_ID('dbo.Authors', 'U') IS NULL
CREATE TABLE dbo.Authors (
    AuthorId INT IDENTITY(1,1) CONSTRAINT PK_Authors PRIMARY KEY,
    FullName NVARCHAR(150) NOT NULL CONSTRAINT UQ_Authors_FullName UNIQUE
);",
@"IF OBJECT_ID('dbo.Readers', 'U') IS NULL
CREATE TABLE dbo.Readers (
    ReaderId INT IDENTITY(1,1) CONSTRAINT PK_Readers PRIMARY KEY,
    FullName NVARCHAR(150) NOT NULL,
    Phone NVARCHAR(30) NULL,
    Email NVARCHAR(120) NULL,
    IsDeleted BIT NOT NULL CONSTRAINT DF_Readers_IsDeleted DEFAULT(0)
);",
@"IF OBJECT_ID('dbo.Books', 'U') IS NULL
CREATE TABLE dbo.Books (
    BookId INT IDENTITY(1,1) CONSTRAINT PK_Books PRIMARY KEY,
    Title NVARCHAR(200) NOT NULL,
    AuthorId INT NOT NULL,
    GenreId INT NOT NULL,
    PublishYear INT NOT NULL CONSTRAINT CK_Books_PublishYear CHECK (PublishYear BETWEEN 1400 AND 2100),
    BookStatus NVARCHAR(30) NOT NULL CONSTRAINT DF_Books_Status DEFAULT(N'В наличии'),
    IsDeleted BIT NOT NULL CONSTRAINT DF_Books_IsDeleted DEFAULT(0),
    CONSTRAINT CK_Books_Status CHECK (BookStatus IN (N'В наличии', N'Выдана', N'Списана')),
    CONSTRAINT FK_Books_Authors FOREIGN KEY (AuthorId) REFERENCES dbo.Authors(AuthorId),
    CONSTRAINT FK_Books_Genres FOREIGN KEY (GenreId) REFERENCES dbo.Genres(GenreId)
);",
@"IF OBJECT_ID('dbo.Loans', 'U') IS NULL
CREATE TABLE dbo.Loans (
    LoanId INT IDENTITY(1,1) CONSTRAINT PK_Loans PRIMARY KEY,
    BookId INT NOT NULL,
    ReaderId INT NOT NULL,
    IssueDate DATE NOT NULL,
    DueDate DATE NOT NULL,
    ReturnDate DATE NULL,
    CONSTRAINT FK_Loans_Books FOREIGN KEY (BookId) REFERENCES dbo.Books(BookId),
    CONSTRAINT FK_Loans_Readers FOREIGN KEY (ReaderId) REFERENCES dbo.Readers(ReaderId),
    CONSTRAINT CK_Loans_Dates CHECK (DueDate >= IssueDate AND (ReturnDate IS NULL OR ReturnDate >= IssueDate))
);",
@"IF OBJECT_ID('dbo.ExtensionRequests', 'U') IS NULL
CREATE TABLE dbo.ExtensionRequests (
    RequestId INT IDENTITY(1,1) CONSTRAINT PK_ExtensionRequests PRIMARY KEY,
    LoanId INT NOT NULL,
    RequestDate DATETIME2 NOT NULL CONSTRAINT DF_ExtensionRequests_RequestDate DEFAULT(SYSDATETIME()),
    RequestedDueDate DATE NOT NULL,
    RequestStatus NVARCHAR(30) NOT NULL CONSTRAINT DF_ExtensionRequests_Status DEFAULT(N'Новая'),
    CONSTRAINT FK_ExtensionRequests_Loans FOREIGN KEY (LoanId) REFERENCES dbo.Loans(LoanId),
    CONSTRAINT CK_ExtensionRequests_Status CHECK (RequestStatus IN (N'Новая', N'Одобрена', N'Отклонена'))
);",
@"IF OBJECT_ID('dbo.DeletionLog', 'U') IS NULL
CREATE TABLE dbo.DeletionLog (
    LogId INT IDENTITY(1,1) CONSTRAINT PK_DeletionLog PRIMARY KEY,
    EntityName NVARCHAR(80) NOT NULL,
    EntityId INT NOT NULL,
    DeletedAt DATETIME2 NOT NULL CONSTRAINT DF_DeletionLog_DeletedAt DEFAULT(SYSDATETIME()),
    DataSnapshot NVARCHAR(MAX) NOT NULL
);",
@"IF OBJECT_ID('dbo.AppUsers', 'U') IS NULL
CREATE TABLE dbo.AppUsers (
    UserId INT IDENTITY(1,1) CONSTRAINT PK_AppUsers PRIMARY KEY,
    Login NVARCHAR(50) NOT NULL CONSTRAINT UQ_AppUsers_Login UNIQUE,
    UserPassword NVARCHAR(50) NOT NULL,
    UserRole NVARCHAR(30) NOT NULL,
    DisplayName NVARCHAR(150) NOT NULL,
    EmployeeId INT NULL,
    ReaderId INT NULL,
    IsActive BIT NOT NULL CONSTRAINT DF_AppUsers_IsActive DEFAULT(1),
    CONSTRAINT CK_AppUsers_Role CHECK (UserRole IN (N'Librarian', N'Reader')),
    CONSTRAINT FK_AppUsers_Readers FOREIGN KEY (ReaderId) REFERENCES dbo.Readers(ReaderId)
);"
            );
        }

        private static void SeedData()
        {
            using var connection = new SqlConnection(AppConnectionString);
            connection.Open();
            using (var check = new SqlCommand("SELECT COUNT(*) FROM dbo.Books", connection))
            {
                if ((int)check.ExecuteScalar() > 0) return;
            }

            string seedSql = @"
INSERT INTO dbo.Genres (GenreName) VALUES
(N'Программирование'), (N'Базы данных'), (N'Аналитика'), (N'Сетевые технологии'), (N'Информационная безопасность');

INSERT INTO dbo.Authors (FullName) VALUES
(N'Роберт Мартин'), (N'Эрих Гамма'), (N'Томас Кормен'), (N'Мартин Фаулер'), (N'Кевин Митник');

INSERT INTO dbo.Readers (FullName, Phone, Email) VALUES
(N'Иванов Артем Сергеевич', N'+7 900 100-01-01', N'ivanov@example.local'),
(N'Петрова Мария Андреевна', N'+7 900 100-01-02', N'petrova@example.local'),
(N'Сидоров Никита Павлович', N'+7 900 100-01-03', N'sidorov@example.local'),
(N'Кузнецова Елена Олеговна', N'+7 900 100-01-04', N'kuznetsova@example.local');

INSERT INTO dbo.Books (Title, AuthorId, GenreId, PublishYear, BookStatus) VALUES
(N'Чистый код 04', 1, 1, 2023, N'Выдана'),
(N'Паттерны проектирования 04', 2, 1, 2022, N'В наличии'),
(N'Алгоритмы: построение и анализ 04', 3, 1, 2021, N'В наличии'),
(N'Рефакторинг 04', 4, 1, 2024, N'Выдана'),
(N'Искусство обмана 04', 5, 5, 2020, N'В наличии'),
(N'SQL для начинающих 04', 1, 2, 2024, N'В наличии'),
(N'Проектирование баз данных 04', 4, 2, 2023, N'Выдана'),
(N'Введение в аналитику данных 04', 3, 3, 2022, N'В наличии'),
(N'Компьютерные сети 04', 2, 4, 2021, N'В наличии'),
(N'Защита информации 04', 5, 5, 2024, N'В наличии');

INSERT INTO dbo.Loans (BookId, ReaderId, IssueDate, DueDate, ReturnDate) VALUES
(1, 1, DATEADD(DAY, -35, CAST(GETDATE() AS date)), DATEADD(DAY, -5, CAST(GETDATE() AS date)), NULL),
(4, 2, DATEADD(DAY, -12, CAST(GETDATE() AS date)), DATEADD(DAY, 18, CAST(GETDATE() AS date)), NULL),
(7, 3, DATEADD(DAY, -40, CAST(GETDATE() AS date)), DATEADD(DAY, -10, CAST(GETDATE() AS date)), NULL);
";
            using var cmd = new SqlCommand(seedSql, connection);
            cmd.ExecuteNonQuery();
        }

        private static void SeedAuthUsers()
        {
            using var connection = new SqlConnection(AppConnectionString);
            connection.Open();
            string sql = @"
DECLARE @reader1 INT = (SELECT ReaderId FROM (SELECT ReaderId, ROW_NUMBER() OVER (ORDER BY ReaderId) AS rn FROM dbo.Readers WHERE IsDeleted=0) x WHERE rn=1);
DECLARE @reader2 INT = (SELECT ReaderId FROM (SELECT ReaderId, ROW_NUMBER() OVER (ORDER BY ReaderId) AS rn FROM dbo.Readers WHERE IsDeleted=0) x WHERE rn=2);
DECLARE @reader3 INT = (SELECT ReaderId FROM (SELECT ReaderId, ROW_NUMBER() OVER (ORDER BY ReaderId) AS rn FROM dbo.Readers WHERE IsDeleted=0) x WHERE rn=3);

IF NOT EXISTS (SELECT 1 FROM dbo.AppUsers WHERE Login=N'librarian')
    INSERT INTO dbo.AppUsers(Login, UserPassword, UserRole, DisplayName, ReaderId) VALUES (N'librarian', N'123', N'Librarian', N'Библиотекарь', NULL);

IF @reader1 IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.AppUsers WHERE Login=N'reader1')
    INSERT INTO dbo.AppUsers(Login, UserPassword, UserRole, DisplayName, ReaderId) SELECT N'reader1', N'123', N'Reader', FullName, ReaderId FROM dbo.Readers WHERE ReaderId=@reader1;

IF @reader2 IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.AppUsers WHERE Login=N'reader2')
    INSERT INTO dbo.AppUsers(Login, UserPassword, UserRole, DisplayName, ReaderId) SELECT N'reader2', N'123', N'Reader', FullName, ReaderId FROM dbo.Readers WHERE ReaderId=@reader2;

IF @reader3 IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.AppUsers WHERE Login=N'reader3')
    INSERT INTO dbo.AppUsers(Login, UserPassword, UserRole, DisplayName, ReaderId) SELECT N'reader3', N'123', N'Reader', FullName, ReaderId FROM dbo.Readers WHERE ReaderId=@reader3;
";
            using var command = new SqlCommand(sql, connection);
            command.ExecuteNonQuery();
        }

    }
}
