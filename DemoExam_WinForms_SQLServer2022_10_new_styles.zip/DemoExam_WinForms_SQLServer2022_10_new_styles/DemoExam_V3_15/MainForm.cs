using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace DemoExam_V3_15
{
    public class MainForm : Form
    {
        private readonly CurrentUser _user;
        private DataGridView gridEmployees;
        private TextBox txtFullName;
        private TextBox txtContacts;
        private ComboBox cmbDepartment;
        private ComboBox cmbPosition;
        private DateTimePicker dtHire;

        private DataGridView gridSalary;
        private DataGridView gridTurnover;
        private DateTimePicker dtFrom;
        private DateTimePicker dtTo;

        private ComboBox cmbEmployeeSelf;
        private DataGridView gridOwnData;
        private DataGridView gridOwnSalary;
        private TextBox txtRequestField;
        private TextBox txtRequestValue;

        private ComboBox cmbDashDepartment;
        private NumericUpDown numMinSalary;
        private NumericUpDown numMaxSalary;
        private DataGridView gridDashboard;
        private Panel panelChart;
        private DataTable chartData;

        public MainForm(CurrentUser user)
        {
            _user = user;
            Text = "Вариант №3. Учет сотрудников. Комплект 15 | SQL Server: " + DatabaseInitializer.ServerName + " | БД: " + DatabaseInitializer.DatabaseName + " | Пользователь: " + _user.DisplayName + " (" + _user.RoleTitle + ")";
            Width = 1200;
            Height = 780;
            StartPosition = FormStartPosition.CenterScreen;
            Font = new Font("Segoe UI", 15F);

            var tabs = new TabControl { Dock = DockStyle.Fill };
            if (_user.IsHr)
            {
                tabs.TabPages.Add(BuildEmployeesTab());
                tabs.TabPages.Add(BuildSalaryAndReportsTab());
                tabs.TabPages.Add(BuildDashboardTab());
            }
            if (_user.IsEmployee)
            {
                tabs.TabPages.Add(BuildEmployeeTab());
            }
            UiTheme.BuildMainShell(this, tabs, "Вариант №3 - учет сотрудников", "Роль: " + _user.RoleTitle + " | Пользователь: " + _user.DisplayName);

            LoadDictionaries();
            if (_user.IsHr)
            {
                LoadEmployees();
                LoadSalary();
                LoadTurnoverReport();
                LoadDashboard();
            }
            if (_user.IsEmployee)
            {
                LoadEmployeeSelf();
            }
        }

        private TabPage BuildEmployeesTab()
        {
            var page = new TabPage("HR: сотрудники");
            var split = new SplitContainer { Dock = DockStyle.Fill, Orientation = Orientation.Horizontal, SplitterDistance = 190, FixedPanel = FixedPanel.Panel1 };
            var form = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 6, RowCount = 3, Padding = new Padding(12) };
            form.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 155));
            form.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 38));
            form.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 115));
            form.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 28));
            form.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 120));
            form.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 34));
            form.RowStyles.Add(new RowStyle(SizeType.Absolute, 42));
            form.RowStyles.Add(new RowStyle(SizeType.Absolute, 42));
            form.RowStyles.Add(new RowStyle(SizeType.Absolute, 52));

            txtFullName = new TextBox { Dock = DockStyle.Fill, PlaceholderText = "ФИО сотрудника" };
            cmbDepartment = new ComboBox { Dock = DockStyle.Fill, DropDownStyle = ComboBoxStyle.DropDownList };
            cmbPosition = new ComboBox { Dock = DockStyle.Fill, DropDownStyle = ComboBoxStyle.DropDownList };
            dtHire = new DateTimePicker { Dock = DockStyle.Fill, Format = DateTimePickerFormat.Short };
            txtContacts = new TextBox { Dock = DockStyle.Fill, PlaceholderText = "Контакты" };

            var btnAdd = new Button { Text = "Добавить", Width = 130, Height = 34 };
            var btnUpdate = new Button { Text = "Изменить", Width = 130, Height = 34 };
            var btnDelete = new Button { Text = "Мягко удалить", Width = 150, Height = 34 };
            var btnRefresh = new Button { Text = "Обновить", Width = 130, Height = 34 };
            btnAdd.Click += (s, e) => AddEmployee();
            btnUpdate.Click += (s, e) => UpdateEmployee();
            btnDelete.Click += (s, e) => DeleteEmployee();
            btnRefresh.Click += (s, e) => LoadEmployees();

            var buttonsPanel = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.LeftToRight, WrapContents = false, AutoScroll = true, Padding = new Padding(0, 8, 0, 0) };
            buttonsPanel.Controls.AddRange(new Control[] { btnAdd, btnUpdate, btnDelete, btnRefresh });

            form.Controls.Add(new Label { Text = "ФИО:", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 0, 0);
            form.Controls.Add(txtFullName, 1, 0);
            form.Controls.Add(new Label { Text = "Отдел:", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 2, 0);
            form.Controls.Add(cmbDepartment, 3, 0);
            form.Controls.Add(new Label { Text = "Должность:", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 4, 0);
            form.Controls.Add(cmbPosition, 5, 0);
            form.Controls.Add(new Label { Text = "Дата приема:", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 0, 1);
            form.Controls.Add(dtHire, 1, 1);
            form.Controls.Add(new Label { Text = "Контакты:", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 2, 1);
            form.Controls.Add(txtContacts, 3, 1);
            form.SetColumnSpan(txtContacts, 3);
            form.Controls.Add(buttonsPanel, 0, 2);
            form.SetColumnSpan(buttonsPanel, 6);

            gridEmployees = NewGrid();
            gridEmployees.SelectionChanged += (s, e) => FillEmployeeFieldsFromGrid();
            split.Panel1.Controls.Add(form);
            split.Panel2.Controls.Add(gridEmployees);
            page.Controls.Add(split);
            return page;
        }

        private TabPage BuildSalaryAndReportsTab()
        {
            var page = new TabPage("HR: зарплаты, бонусы, текучесть");
            var layout = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 4, ColumnCount = 1 };
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 45));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 45));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 55));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 55));

            var lblSalary = new Label { Text = "Информация о зарплатах и бонусах сотрудников", Dock = DockStyle.Fill, Padding = new Padding(8, 15, 0, 0), Font = new Font(Font, FontStyle.Bold) };
            gridSalary = NewGrid();
            var reportPanel = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.LeftToRight, WrapContents = false, AutoScroll = true, Padding = new Padding(8) };
            dtFrom = new DateTimePicker { Width = 130, Format = DateTimePickerFormat.Short, Value = DateTime.Today.AddMonths(-2) };
            dtTo = new DateTimePicker { Width = 130, Format = DateTimePickerFormat.Short, Value = DateTime.Today };
            var btnReport = new Button { Text = "Сформировать отчет", Width = 170 };
            btnReport.Click += (s, e) => LoadTurnoverReport();
            reportPanel.Controls.AddRange(new Control[] {
                new Label { Text = "Период с:", AutoSize = true, Padding = new Padding(0, 7, 0, 0) }, dtFrom,
                new Label { Text = "по:", AutoSize = true, Padding = new Padding(0, 7, 0, 0) }, dtTo,
                btnReport
            });
            gridTurnover = NewGrid();
            layout.Controls.Add(lblSalary, 0, 0);
            layout.Controls.Add(gridSalary, 0, 1);
            layout.Controls.Add(reportPanel, 0, 2);
            layout.Controls.Add(gridTurnover, 0, 3);
            page.Controls.Add(layout);
            return page;
        }

        private TabPage BuildEmployeeTab()
        {
            var page = new TabPage("Сотрудник");
            var layout = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 4, ColumnCount = 1 };
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 60));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 35));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 35));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 90));

            var top = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.LeftToRight, WrapContents = false, AutoScroll = true, Padding = new Padding(8) };
            cmbEmployeeSelf = new ComboBox { Width = 330, DropDownStyle = ComboBoxStyle.DropDownList };
            var btnLoad = new Button { Text = "Показать мои данные", Width = 170 };
            btnLoad.Click += (s, e) => LoadOwnData();
            top.Controls.AddRange(new Control[] { new Label { Text = "Сотрудник:", AutoSize = true, Padding = new Padding(0, 7, 0, 0) }, cmbEmployeeSelf, btnLoad });

            gridOwnData = NewGrid();
            gridOwnSalary = NewGrid();
            var requestPanel = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.LeftToRight, WrapContents = false, AutoScroll = true, Padding = new Padding(8) };
            txtRequestField = new TextBox { Width = 170, Text = "Контакты" };
            txtRequestValue = new TextBox { Width = 420, PlaceholderText = "Новое значение" };
            var btnRequest = new Button { Text = "Отправить запрос на изменение", Width = 240 };
            btnRequest.Click += (s, e) => CreateChangeRequest();
            requestPanel.Controls.AddRange(new Control[] {
                new Label { Text = "Поле:", AutoSize = true, Padding = new Padding(0, 7, 0, 0) }, txtRequestField,
                new Label { Text = "Новое значение:", AutoSize = true, Padding = new Padding(0, 7, 0, 0) }, txtRequestValue,
                btnRequest
            });
            layout.Controls.Add(top, 0, 0);
            layout.Controls.Add(gridOwnData, 0, 1);
            layout.Controls.Add(gridOwnSalary, 0, 2);
            layout.Controls.Add(requestPanel, 0, 3);
            page.Controls.Add(layout);
            return page;
        }

        private TabPage BuildDashboardTab()
        {
            var page = new TabPage("Интерактивный дашборд");
            var layout = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 3, ColumnCount = 1 };
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 55));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 45));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 55));

            var filters = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.LeftToRight, WrapContents = false, AutoScroll = true, Padding = new Padding(8) };
            cmbDashDepartment = new ComboBox { Width = 240, DropDownStyle = ComboBoxStyle.DropDownList };
            numMinSalary = new NumericUpDown { Width = 115, Minimum = 0, Maximum = 1500000, Increment = 5000, Value = 0 };
            numMaxSalary = new NumericUpDown { Width = 115, Minimum = 0, Maximum = 1500000, Increment = 5000, Value = 200000 };
            var btnRefresh = new Button { Text = "Обновить дашборд", Width = 165 };
            btnRefresh.Click += (s, e) => LoadDashboard();
            cmbDashDepartment.SelectedIndexChanged += (s, e) => LoadDashboard();
            filters.Controls.AddRange(new Control[] {
                new Label { Text = "Отдел:", AutoSize = true, Padding = new Padding(0, 7, 0, 0) }, cmbDashDepartment,
                new Label { Text = "Зарплата от:", AutoSize = true, Padding = new Padding(0, 7, 0, 0) }, numMinSalary,
                new Label { Text = "до:", AutoSize = true, Padding = new Padding(0, 7, 0, 0) }, numMaxSalary,
                btnRefresh
            });

            panelChart = new Panel { Dock = DockStyle.Fill, BackColor = UiTheme.CardBack, BorderStyle = BorderStyle.FixedSingle };
            panelChart.Paint += (s, e) => DrawBarChart(e.Graphics, chartData, "PositionName", "EmployeeCount", "Распределение сотрудников по должностям");
            gridDashboard = NewGrid();
            layout.Controls.Add(filters, 0, 0);
            layout.Controls.Add(panelChart, 0, 1);
            layout.Controls.Add(gridDashboard, 0, 2);
            page.Controls.Add(layout);
            return page;
        }

        private DataGridView NewGrid()
        {
            return new DataGridView
            {
                Dock = DockStyle.Fill,
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false
            };
        }

        private void LoadDictionaries()
        {
            if (cmbDepartment != null)
                FillCombo(cmbDepartment, "SELECT DepartmentId AS Id, DepartmentName AS Text FROM dbo.Departments ORDER BY DepartmentName");
            if (cmbPosition != null)
                FillCombo(cmbPosition, "SELECT PositionId AS Id, PositionName AS Text FROM dbo.Positions ORDER BY PositionName");
            if (cmbDashDepartment != null)
                FillCombo(cmbDashDepartment, "SELECT 0 AS Id, N'Все' AS Text UNION ALL SELECT DepartmentId, DepartmentName FROM dbo.Departments ORDER BY Text");
        }

        private void FillCombo(ComboBox combo, string sql)
        {
            if (combo == null) return;
            combo.Items.Clear();
            foreach (DataRow row in Db.Query(sql).Rows)
                combo.Items.Add(new ComboItem { Id = Convert.ToInt32(row["Id"]), Text = Convert.ToString(row["Text"]) });
            if (combo.Items.Count > 0) combo.SelectedIndex = 0;
        }

        private int SelectedComboId(ComboBox combo)
        {
            return combo.SelectedItem is ComboItem item ? item.Id : 0;
        }

        private int? SelectedGridId(DataGridView grid)
        {
            if (grid.CurrentRow == null || grid.CurrentRow.Cells["Id"] == null) return null;
            return Convert.ToInt32(grid.CurrentRow.Cells["Id"].Value);
        }

        private void LoadEmployees()
        {
            gridEmployees.DataSource = Db.Query(@"
SELECT e.EmployeeId AS Id, e.FullName AS [ФИО], d.DepartmentName AS [Отдел], p.PositionName AS [Должность],
       e.HireDate AS [Дата приема], e.Contacts AS [Контакты]
FROM dbo.Employees e
JOIN dbo.Departments d ON d.DepartmentId = e.DepartmentId
JOIN dbo.Positions p ON p.PositionId = e.PositionId
WHERE e.IsDeleted = 0
ORDER BY e.FullName");
            HideId(gridEmployees);
        }

        private void FillEmployeeFieldsFromGrid()
        {
            if (gridEmployees.CurrentRow == null) return;
            txtFullName.Text = Convert.ToString(gridEmployees.CurrentRow.Cells["ФИО"].Value);
            txtContacts.Text = Convert.ToString(gridEmployees.CurrentRow.Cells["Контакты"].Value);
            if (DateTime.TryParse(Convert.ToString(gridEmployees.CurrentRow.Cells["Дата приема"].Value), out DateTime hire)) dtHire.Value = hire;
            SelectComboByText(cmbDepartment, Convert.ToString(gridEmployees.CurrentRow.Cells["Отдел"].Value));
            SelectComboByText(cmbPosition, Convert.ToString(gridEmployees.CurrentRow.Cells["Должность"].Value));
        }

        private void SelectComboByText(ComboBox combo, string text)
        {
            for (int i = 0; i < combo.Items.Count; i++)
                if (combo.Items[i].ToString() == text) { combo.SelectedIndex = i; return; }
        }

        private void AddEmployee()
        {
            if (string.IsNullOrWhiteSpace(txtFullName.Text)) { MessageBox.Show("Введите ФИО сотрудника."); return; }
            Db.Execute(@"INSERT INTO dbo.Employees (FullName, DepartmentId, PositionId, HireDate, Contacts) VALUES (@f, @d, @p, @h, @c);
                         DECLARE @newId INT = SCOPE_IDENTITY();
                         INSERT INTO dbo.Salaries(EmployeeId, SalaryAmount, BonusAmount, SalaryDate) VALUES (@newId, 0, 0, CAST(GETDATE() AS date));
                         INSERT INTO dbo.TurnoverRecords(EmployeeId, EventType, EventDate, Comment) VALUES (@newId, N'Прием', @h, N'Добавлен HR-менеджером');",
                Db.P("@f", txtFullName.Text.Trim()), Db.P("@d", SelectedComboId(cmbDepartment)), Db.P("@p", SelectedComboId(cmbPosition)), Db.P("@h", dtHire.Value.Date), Db.P("@c", txtContacts.Text.Trim()));
            LoadEmployees(); LoadSalary(); LoadEmployeeSelf(); LoadDashboard();
        }

        private void UpdateEmployee()
        {
            var id = SelectedGridId(gridEmployees);
            if (id == null) { MessageBox.Show("Выберите сотрудника."); return; }
            Db.Execute(@"UPDATE dbo.Employees SET FullName=@f, DepartmentId=@d, PositionId=@p, HireDate=@h, Contacts=@c WHERE EmployeeId=@id",
                Db.P("@f", txtFullName.Text.Trim()), Db.P("@d", SelectedComboId(cmbDepartment)), Db.P("@p", SelectedComboId(cmbPosition)), Db.P("@h", dtHire.Value.Date), Db.P("@c", txtContacts.Text.Trim()), Db.P("@id", id.Value));
            LoadEmployees(); LoadSalary(); LoadEmployeeSelf(); LoadDashboard();
        }

        private void DeleteEmployee()
        {
            var id = SelectedGridId(gridEmployees);
            if (id == null) { MessageBox.Show("Выберите сотрудника."); return; }
            if (MessageBox.Show("Сотрудник будет скрыт, но запись сохранится для просмотра и восстановления. Продолжить?", "Мягкое удаление", MessageBoxButtons.YesNo) != DialogResult.Yes) return;
            Db.Execute(@"INSERT INTO dbo.DeletionLog(EntityName, EntityId, DataSnapshot)
                         SELECT N'Employees', EmployeeId, CONCAT(FullName, N'; ', Contacts) FROM dbo.Employees WHERE EmployeeId=@id;
                         UPDATE dbo.Employees SET IsDeleted=1 WHERE EmployeeId=@id;
                         INSERT INTO dbo.TurnoverRecords(EmployeeId, EventType, EventDate, Comment) VALUES (@id, N'Увольнение', CAST(GETDATE() AS date), N'Мягкое удаление');", Db.P("@id", id.Value));
            LoadEmployees(); LoadSalary(); LoadEmployeeSelf(); LoadDashboard();
        }

        private void LoadSalary()
        {
            gridSalary.DataSource = Db.Query(@"
SELECT e.EmployeeId AS Id, e.FullName AS [ФИО], d.DepartmentName AS [Отдел], p.PositionName AS [Должность],
       s.SalaryAmount AS [Зарплата], s.BonusAmount AS [Бонус], s.SalaryDate AS [Дата начисления]
FROM dbo.Salaries s
JOIN dbo.Employees e ON e.EmployeeId=s.EmployeeId
JOIN dbo.Departments d ON d.DepartmentId=e.DepartmentId
JOIN dbo.Positions p ON p.PositionId=e.PositionId
WHERE e.IsDeleted=0
ORDER BY e.FullName, s.SalaryDate DESC");
            HideId(gridSalary);
        }

        private void LoadTurnoverReport()
        {
            gridTurnover.DataSource = Db.Query(@"
SELECT t.EventDate AS [Дата], t.EventType AS [Событие], e.FullName AS [Сотрудник], d.DepartmentName AS [Отдел], t.Comment AS [Комментарий]
FROM dbo.TurnoverRecords t
JOIN dbo.Employees e ON e.EmployeeId=t.EmployeeId
JOIN dbo.Departments d ON d.DepartmentId=e.DepartmentId
WHERE t.EventDate BETWEEN @from AND @to
ORDER BY t.EventDate DESC", Db.P("@from", dtFrom.Value.Date), Db.P("@to", dtTo.Value.Date));
        }

        private void LoadEmployeeSelf()
        {
            if (cmbEmployeeSelf == null) return;
            if (_user.IsEmployee && _user.EmployeeId.HasValue)
            {
                FillCombo(cmbEmployeeSelf, $"SELECT EmployeeId AS Id, FullName AS Text FROM dbo.Employees WHERE IsDeleted=0 AND EmployeeId={_user.EmployeeId.Value}");
                cmbEmployeeSelf.Enabled = false;
            }
            else
            {
                FillCombo(cmbEmployeeSelf, "SELECT EmployeeId AS Id, FullName AS Text FROM dbo.Employees WHERE IsDeleted=0 ORDER BY FullName");
            }
            LoadOwnData();
        }

        private void LoadOwnData()
        {
            if (cmbEmployeeSelf == null || gridOwnData == null || gridOwnSalary == null) return;
            int employeeId = SelectedComboId(cmbEmployeeSelf);
            if (employeeId <= 0) return;
            gridOwnData.DataSource = Db.Query(@"
SELECT e.FullName AS [ФИО], p.PositionName AS [Должность], d.DepartmentName AS [Отдел], e.HireDate AS [Дата приема], e.Contacts AS [Контакты]
FROM dbo.Employees e
JOIN dbo.Departments d ON d.DepartmentId=e.DepartmentId
JOIN dbo.Positions p ON p.PositionId=e.PositionId
WHERE e.EmployeeId=@id", Db.P("@id", employeeId));

            gridOwnSalary.DataSource = Db.Query(@"
SELECT SalaryAmount AS [Зарплата], BonusAmount AS [Бонус], SalaryDate AS [Дата начисления]
FROM dbo.Salaries
WHERE EmployeeId=@id
ORDER BY SalaryDate DESC", Db.P("@id", employeeId));
        }

        private void CreateChangeRequest()
        {
            int employeeId = SelectedComboId(cmbEmployeeSelf);
            if (string.IsNullOrWhiteSpace(txtRequestField.Text) || string.IsNullOrWhiteSpace(txtRequestValue.Text))
            {
                MessageBox.Show("Заполните поле и новое значение.");
                return;
            }
            Db.Execute(@"INSERT INTO dbo.ChangeRequests(EmployeeId, FieldName, NewValue) VALUES (@id, @field, @value)",
                Db.P("@id", employeeId), Db.P("@field", txtRequestField.Text.Trim()), Db.P("@value", txtRequestValue.Text.Trim()));
            MessageBox.Show("Запрос на изменение отправлен HR-менеджеру.");
        }

        private void LoadDashboard()
        {
            if (cmbDashDepartment == null) return;
            int departmentId = SelectedComboId(cmbDashDepartment);
            decimal minSalary = numMinSalary?.Value ?? 0;
            decimal maxSalary = numMaxSalary?.Value ?? 200000;
            var parameters = new List<Microsoft.Data.SqlClient.SqlParameter> { Db.P("@min", minSalary), Db.P("@max", maxSalary) };
            string where = "WHERE e.IsDeleted=0 AND s.SalaryAmount BETWEEN @min AND @max";
            if (departmentId > 0) { where += " AND e.DepartmentId=@dep"; parameters.Add(Db.P("@dep", departmentId)); }

            chartData = Db.Query($@"
SELECT p.PositionName, COUNT(*) AS EmployeeCount
FROM dbo.Employees e
JOIN dbo.Positions p ON p.PositionId=e.PositionId
JOIN dbo.Salaries s ON s.EmployeeId=e.EmployeeId
{where}
GROUP BY p.PositionName
ORDER BY p.PositionName", parameters.ToArray());

            gridDashboard.DataSource = Db.Query($@"
SELECT e.FullName AS [ФИО], d.DepartmentName AS [Отдел], p.PositionName AS [Должность],
       s.SalaryAmount AS [Зарплата], s.BonusAmount AS [Бонус], e.HireDate AS [Дата приема]
FROM dbo.Employees e
JOIN dbo.Departments d ON d.DepartmentId=e.DepartmentId
JOIN dbo.Positions p ON p.PositionId=e.PositionId
JOIN dbo.Salaries s ON s.EmployeeId=e.EmployeeId
{where}
ORDER BY e.FullName", parameters.ToArray());
            panelChart?.Invalidate();
        }

        private void DrawBarChart(Graphics g, DataTable data, string labelColumn, string valueColumn, string title)
        {
            g.Clear(UiTheme.CardBack);
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            using var titleFont = new Font(Font.FontFamily, 12F, FontStyle.Bold);
            g.DrawString(title, titleFont, UiTheme.TextBrush, 12, 15);
            if (data == null || data.Rows.Count == 0)
            {
                g.DrawString("Нет данных для выбранного фильтра", Font, UiTheme.MutedBrush, 12, 45);
                return;
            }
            int left = 50, top = 55, bottom = panelChart.Height - 45, right = panelChart.Width - 25;
            int chartHeight = Math.Max(15, bottom - top);
            int chartWidth = Math.Max(15, right - left);
            int max = data.AsEnumerable().Max(r => Convert.ToInt32(r[valueColumn]));
            int barWidth = Math.Max(20, chartWidth / data.Rows.Count - 18);
            g.DrawLine(UiTheme.AxisPen, left, top, left, bottom);
            g.DrawLine(UiTheme.AxisPen, left, bottom, right, bottom);
            for (int i = 0; i < data.Rows.Count; i++)
            {
                string label = Convert.ToString(data.Rows[i][labelColumn]);
                int value = Convert.ToInt32(data.Rows[i][valueColumn]);
                int barHeight = (int)(chartHeight * (value / (double)Math.Max(1, max)));
                int x = left + 12 + i * (barWidth + 18);
                int y = bottom - barHeight;
                g.FillRectangle(UiTheme.ChartBrush, x, y, barWidth, barHeight);
                g.DrawRectangle(UiTheme.ChartPen, x, y, barWidth, barHeight);
                g.DrawString(value.ToString(), Font, UiTheme.TextBrush, x + barWidth / 3, y - 22);
                string shortLabel = label.Length > 16 ? label.Substring(0, 16) + "..." : label;
                g.DrawString(shortLabel, Font, UiTheme.TextBrush, x - 5, bottom + 5);
            }
        }

        private void HideId(DataGridView grid)
        {
            if (grid.Columns.Contains("Id")) grid.Columns["Id"].Visible = false;
        }
    }
}
