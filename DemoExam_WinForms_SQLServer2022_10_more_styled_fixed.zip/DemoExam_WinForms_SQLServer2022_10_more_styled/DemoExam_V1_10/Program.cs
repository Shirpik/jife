using System;
using System.Windows.Forms;

namespace DemoExam_V1_10
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.SetHighDpiMode(HighDpiMode.SystemAware);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            try
            {
                DatabaseInitializer.EnsureDatabase();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Не удалось создать или открыть базу данных SQL Server.\n\n" +
                    "Проверьте, что установлен и запущен SQL Server 2022/SQL Server Express.\n" +
                    "Приложение пробует серверы: .\\SQLEXPRESS, (localdb)\\MSSQLLocalDB, localhost.\n\n" +
                    ex.Message,
                    "Ошибка подключения к SQL Server",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return;
            }

            using (var loginForm = new LoginForm())
            {
                if (loginForm.ShowDialog() != DialogResult.OK || loginForm.AuthenticatedUser == null)
                    return;

                Application.Run(new MainForm(loginForm.AuthenticatedUser));
            }
        }
    }
}
