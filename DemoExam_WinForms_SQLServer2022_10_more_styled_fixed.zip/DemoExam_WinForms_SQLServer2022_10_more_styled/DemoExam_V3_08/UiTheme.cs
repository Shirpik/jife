using System.Drawing;
using System.Windows.Forms;

namespace DemoExam_V3_08
{
    public static class UiTheme
    {
        public const string StyleName = "";
        public const string MainFontName = "Segoe UI Semibold";

        public static readonly Color Primary = ColorTranslator.FromHtml("#047857");
        public static readonly Color Secondary = ColorTranslator.FromHtml("#065F46");
        public static readonly Color Accent = ColorTranslator.FromHtml("#14B8A6");
        public static readonly Color AppBack = ColorTranslator.FromHtml("#ECFDF5");
        public static readonly Color ContentBack = ColorTranslator.FromHtml("#FFFFFF");
        public static readonly Color CardBack = ColorTranslator.FromHtml("#D1FAE5");
        public static readonly Color InputBack = ColorTranslator.FromHtml("#FFFFFF");
        public static readonly Color TextColor = ColorTranslator.FromHtml("#064E3B");
        public static readonly Color MutedColor = ColorTranslator.FromHtml("#0F766E");
        public static readonly Color HeaderTextColor = ColorTranslator.FromHtml("#FFFFFF");
        public static readonly Color GridHeaderBack = ColorTranslator.FromHtml("#A7F3D0");
        public static readonly Color GridAltBack = ColorTranslator.FromHtml("#F0FDF4");
        public static readonly Color ChartColor = ColorTranslator.FromHtml("#10B981");
        public static readonly Color ChartBorderColor = ColorTranslator.FromHtml("#047857");
        public static readonly Color AxisColor = ColorTranslator.FromHtml("#065F46");

        public static readonly SolidBrush TextBrush = new SolidBrush(TextColor);
        public static readonly SolidBrush MutedBrush = new SolidBrush(MutedColor);
        public static readonly SolidBrush ChartBrush = new SolidBrush(ChartColor);
        public static readonly Pen ChartPen = new Pen(ChartBorderColor, 2);
        public static readonly Pen AxisPen = new Pen(AxisColor, 1);

        public static void BuildMainShell(Form form, Control content, string title, string subtitle)
        {
            form.BackColor = AppBack;
            form.Font = new Font(MainFontName, 10F);

            var root = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 2,
                BackColor = AppBack,
                Padding = new Padding(0)
            };
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 78));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

            var header = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Primary,
                Padding = new Padding(18, 10, 18, 8)
            };
            var titleLabel = new Label
            {
                Text = title,
                Dock = DockStyle.Top,
                Height = 32,
                ForeColor = HeaderTextColor,
                BackColor = Color.Transparent,
                Font = new Font(MainFontName, 15F, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleLeft
            };
            var subtitleLabel = new Label
            {
                Text = subtitle + "  •  SQL Server: " + DatabaseInitializer.ServerName + "  •  БД: " + DatabaseInitializer.DatabaseName,
                Dock = DockStyle.Fill,
                ForeColor = HeaderTextColor,
                BackColor = Color.Transparent,
                Font = new Font(MainFontName, 9.5F, FontStyle.Regular),
                TextAlign = ContentAlignment.MiddleLeft,
                AutoEllipsis = true
            };
            header.Controls.Add(subtitleLabel);
            header.Controls.Add(titleLabel);

            content.Dock = DockStyle.Fill;
            form.Controls.Clear();
            root.Controls.Add(header, 0, 0);
            root.Controls.Add(content, 0, 1);
            form.Controls.Add(root);

            ApplyControlTree(form);
            header.BackColor = Primary;
            titleLabel.ForeColor = HeaderTextColor;
            subtitleLabel.ForeColor = HeaderTextColor;
            titleLabel.BackColor = Color.Transparent;
            subtitleLabel.BackColor = Color.Transparent;
        }

        public static void ApplyLogin(Form form, string title, string subtitle)
        {
            form.Text = title;
            form.BackColor = AppBack;
            form.Font = new Font(MainFontName, 10F);
            ApplyControlTree(form);

            foreach (Control control in form.Controls)
            {
                if (control is TableLayoutPanel panel)
                {
                    panel.BackColor = ContentBack;
                    panel.Padding = new Padding(24);
                    panel.CellBorderStyle = TableLayoutPanelCellBorderStyle.None;
                }
            }

            foreach (Control control in GetAllControls(form))
            {
                if (control is Label label && label.Text == "Вход в систему")
                {
                    label.Text = title;
                    label.ForeColor = Primary;
                    label.Font = new Font(MainFontName, 14F, FontStyle.Bold);
                }
            }
        }

        public static void ApplyControlTree(Control root)
        {
            ApplyOne(root);
            foreach (Control child in root.Controls)
                ApplyControlTree(child);
        }

        private static void ApplyOne(Control control)
        {
            control.Font = new Font(MainFontName, control.Font.Size, control.Font.Style);
            control.ForeColor = TextColor;

            if (control is Form form)
            {
                form.BackColor = AppBack;
                return;
            }

            if (control is TabControl tabControl)
            {
                tabControl.BackColor = ContentBack;
                tabControl.Alignment = TabAlignment.Top;
                tabControl.Font = new Font(MainFontName, 10F, FontStyle.Bold);
                return;
            }

            if (control is TabPage tabPage)
            {
                tabPage.BackColor = ContentBack;
                tabPage.ForeColor = TextColor;
                return;
            }

            if (control is DataGridView grid)
            {
                grid.BackgroundColor = ContentBack;
                grid.BorderStyle = BorderStyle.None;
                grid.EnableHeadersVisualStyles = false;
                grid.ColumnHeadersDefaultCellStyle.BackColor = GridHeaderBack;
                grid.ColumnHeadersDefaultCellStyle.ForeColor = TextColor;
                grid.ColumnHeadersDefaultCellStyle.Font = new Font(MainFontName, 10F, FontStyle.Bold);
                grid.DefaultCellStyle.BackColor = ContentBack;
                grid.DefaultCellStyle.ForeColor = TextColor;
                grid.DefaultCellStyle.SelectionBackColor = Primary;
                grid.DefaultCellStyle.SelectionForeColor = HeaderTextColor;
                grid.AlternatingRowsDefaultCellStyle.BackColor = GridAltBack;
                grid.GridColor = CardBack;
                grid.RowHeadersVisible = false;
                return;
            }

            if (control is Button button)
            {
                button.BackColor = Primary;
                button.ForeColor = HeaderTextColor;
                button.FlatStyle = FlatStyle.Flat;
                button.FlatAppearance.BorderColor = Secondary;
                button.FlatAppearance.BorderSize = 1;
                button.Cursor = Cursors.Hand;
                return;
            }

            if (control is TextBox || control is ComboBox || control is NumericUpDown || control is DateTimePicker)
            {
                control.BackColor = InputBack;
                control.ForeColor = TextColor;
                return;
            }

            if (control is CheckBox checkBox)
            {
                checkBox.BackColor = ContentBack;
                checkBox.ForeColor = TextColor;
                return;
            }

            if (control is Label label)
            {
                label.ForeColor = TextColor;
                label.BackColor = Color.Transparent;
                return;
            }

            if (control is Panel || control is FlowLayoutPanel || control is TableLayoutPanel || control is SplitContainer)
            {
                control.BackColor = ContentBack;
            }
        }

        private static Control[] GetAllControls(Control root)
        {
            var list = new System.Collections.Generic.List<Control>();
            foreach (Control child in root.Controls)
            {
                list.Add(child);
                list.AddRange(GetAllControls(child));
            }
            return list.ToArray();
        }
    }
}
