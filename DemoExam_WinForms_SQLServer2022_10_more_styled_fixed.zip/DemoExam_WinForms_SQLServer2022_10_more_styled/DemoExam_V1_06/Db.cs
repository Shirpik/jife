using System;
using System.Data;
using System.Linq;
using Microsoft.Data.SqlClient;

namespace DemoExam_V1_06
{
    public static class Db
    {
        private static SqlParameter[] CloneParameters(SqlParameter[] parameters)
        {
            if (parameters == null || parameters.Length == 0) return System.Array.Empty<SqlParameter>();
            return parameters.Select(p => new SqlParameter(p.ParameterName, p.Value ?? DBNull.Value)).ToArray();
        }

        public static SqlParameter P(string name, object value)
        {
            return new SqlParameter(name, value ?? DBNull.Value);
        }

        public static DataTable Query(string sql, params SqlParameter[] parameters)
        {
            using var connection = new SqlConnection(DatabaseInitializer.AppConnectionString);
            using var command = new SqlCommand(sql, connection);
            if (parameters != null && parameters.Length > 0)
                command.Parameters.AddRange(CloneParameters(parameters));
            using var adapter = new SqlDataAdapter(command);
            var table = new DataTable();
            adapter.Fill(table);
            return table;
        }

        public static int Execute(string sql, params SqlParameter[] parameters)
        {
            using var connection = new SqlConnection(DatabaseInitializer.AppConnectionString);
            using var command = new SqlCommand(sql, connection);
            if (parameters != null && parameters.Length > 0)
                command.Parameters.AddRange(CloneParameters(parameters));
            connection.Open();
            return command.ExecuteNonQuery();
        }

        public static object Scalar(string sql, params SqlParameter[] parameters)
        {
            using var connection = new SqlConnection(DatabaseInitializer.AppConnectionString);
            using var command = new SqlCommand(sql, connection);
            if (parameters != null && parameters.Length > 0)
                command.Parameters.AddRange(CloneParameters(parameters));
            connection.Open();
            return command.ExecuteScalar();
        }
    }

    public sealed class ComboItem
    {
        public int Id { get; set; }
        public string Text { get; set; }
        public override string ToString() => Text;
    }
}
